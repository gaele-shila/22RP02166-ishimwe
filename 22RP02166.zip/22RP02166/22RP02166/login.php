<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body><center>
    <form action="login_insert.php" method="POST">
        <fieldset style="width: 300px; background-color: powderblue;">
            <center>
                <h1>Register</h1>
                <table>
                    <tr>
                        <td>Username</td>
                        <td><input type="text" name="username" required></td>
                    </tr>
                    <tr>
                        <td>Password</td>
                        <td><input type="password" name="password" required></td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td><input type="email" name="email" required></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center ; ">
                            <input type="submit" value="login" name="send">
                        </td>
                    </tr>
                </table>
            </center>
        </fieldset>
    </form>
</center>
</body>
</html>
