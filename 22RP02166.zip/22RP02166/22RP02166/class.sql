-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2024 at 07:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `class`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `age` int(11) DEFAULT NULL CHECK (`age` >= 0),
  `gender` enum('Male','Female','Other') NOT NULL,
  `comment` text DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `tel`, `username`, `password`, `email`, `age`, `gender`, `comment`, `file`, `image`, `created_at`, `updated_at`) VALUES
(3, '0782466150', 'shema', '123', 'gloria@gmail.com', 12, '', 'football player', 'Activity 1.docx', '20240206_234618.jpg', '2024-08-06 15:22:21', '2024-08-06 15:24:08'),
(5, '0734447613', 'shila', '123', 'rumanzivarely@gmail.com', 40, '', 'model', '22RP02166.docx', '1707778070306.jpg', '2024-08-06 15:37:22', '2024-08-06 15:37:22'),
(6, '0782246180', 'manzi', '1234', 'ishimwegaelle1@gmail.com', 34, '', 'model', '22RP03168_Assignment[1].docx', 'IMG-20240207-WA0016.jpg', '2024-08-06 15:39:41', '2024-08-06 16:01:04'),
(7, '0784819749', 'millha', '@@123', 'aimabletuyizere63@gmail.com', 32, '', 'News reporter', 'LO.3.1 ADMINISTER USER ACCOUNT AND SECURITY.pptx', 'IMG-20240205-WA0036.jpg', '2024-08-06 16:34:51', '2024-08-06 16:34:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `created_at`, `updated_at`) VALUES
(1, 'gaelle', '123', 'ishimwegaelle1@gmail.com', '2024-08-06 15:12:12', '2024-08-06 15:12:12'),
(2, 'lea', '123', 'aimabletuyizere63@gmail.com', '2024-08-06 15:35:32', '2024-08-06 15:35:32'),
(12, 'rayra', '1234', 'rumanzivarely@gmail.com', '2024-08-06 16:36:13', '2024-08-06 16:36:13'),
(13, 'kiki', '##45', 'gloria@gmail.com', '2024-08-06 16:39:17', '2024-08-06 16:39:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
