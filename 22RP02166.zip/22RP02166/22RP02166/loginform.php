<?php
session_start();
include('connection.php');
if (isset($_POST['login'])){

$username = $_POST['username'];
$password = $_POST['password'];

$result=mysqli_query($con,"SELECT * FROM users WHERE username='$username' and password='$password'");
$count1=mysqli_num_rows($result);
$fetch=mysqli_fetch_array($result);

if($count1==0){
    echo"invalid username";
    header('location:loginform.php');
}
else{
    if($fetch['username']==$username && $fetch['password']==$password){
        $_SESSION['username']=$username;
        header('location:select.php');
    }
    else{
        echo"invalid username or password";
    }
}
}
?>

<html>
<head><title></title></head>
<body><center>
<form action="" method="POST"><center>
<h1><b><u>ADMIN REGISTRATION<u></b></h1><br>
<table>
    <tr><td>Names:</td><td><input type="text" name="username" ></td></tr>
    <tr><td>Password:</td><td><input type="password" name="password" ></td></tr>
    
    <tr><td></td><td><input type="submit"  name="login" value="login" ></td></tr>

</table>
</center>
</Form>

</center>

</body>


</html>
